package reynaldocv.iot_project.conexion;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Servicio {
    public static final String URL_base="http://reynaldocv.pythonanywhere.com/";

    @GET("IoT")
    Call<Mensaje> mensajear();

    @GET("Cam")
    Call<Mensaje> significado_foto();

    @GET("Vagas")
    Call<Mensaje> significado_vagas();

}
