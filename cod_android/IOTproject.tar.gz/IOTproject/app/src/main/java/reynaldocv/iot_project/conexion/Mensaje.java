package reynaldocv.iot_project.conexion;
import java.util.List;

public class Mensaje {
    public List<Output> output;
}
