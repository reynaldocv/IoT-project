package reynaldocv.iot_project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import okhttp3.Cache;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import reynaldocv.iot_project.conexion.Output;
import reynaldocv.iot_project.conexion.Servicio;
import reynaldocv.iot_project.conexion.Mensaje;


public class iot extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iot);

        Button btn_cam = findViewById(R.id.btn_camera2);
        Button btn_tem = findViewById(R.id.btn_camera3);

        Button btn_con = findViewById(R.id.btn_camera);
        final ImageView imv_fot = findViewById(R.id.imageView);
        final TextView txv_txt = findViewById(R.id.textView2);


        btn_con.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // subir la imagen
                txv_txt.setText("...");

                //recupera el servicio IOT
                Retrofit rf = new Retrofit.Builder()
                        .baseUrl(Servicio.URL_base)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                Servicio serv =rf.create(Servicio.class);
                Call<Mensaje> que = serv.mensajear();

                que.enqueue(new Callback<Mensaje>() {
                    @Override
                    public void onResponse(Call<Mensaje> call, Response<Mensaje> response) {
                        if (!response.isSuccessful()) {
                            Log.e("TAG", "ERROR > " + response.code());
                        } else {
                            Mensaje msg_ = response.body();
                            for (Output output : msg_.output){
                                txv_txt.setText(output.msg);

                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<Mensaje> call, Throwable t) {
                        Log.e("TAG", "Error:" + t.getMessage());
                    }
                });
                Picasso.get().load("https://www.ime.usp.br/~reynaldo/avatar.jpg").into(imv_fot);

            }
        });
        btn_cam.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // subir la imagen
                txv_txt.setText("...");

                //recupera el servicio IOT
                Retrofit rf = new Retrofit.Builder()
                        .baseUrl(Servicio.URL_base)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                Servicio serv =rf.create(Servicio.class);
                Call<Mensaje> que = serv.significado_foto();

                que.enqueue(new Callback<Mensaje>() {
                    @Override
                    public void onResponse(Call<Mensaje> call, Response<Mensaje> response) {
                        if (!response.isSuccessful()) {
                            Log.e("TAG", "ERROR > " + response.code());
                        } else {
                            Mensaje msg_ = response.body();
                            for (Output output : msg_.output){
                                txv_txt.setText(output.msg);

                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<Mensaje> call, Throwable t) {
                        Log.e("TAG", "Error:" + t.getMessage());
                    }
                });
            }
        });
        btn_tem.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // subir la imagen
                txv_txt.setText("...");

                //recupera el servicio IOT
                Retrofit rf = new Retrofit.Builder()
                        .baseUrl(Servicio.URL_base)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                Servicio serv =rf.create(Servicio.class);
                Call<Mensaje> que = serv.significado_vagas();

                que.enqueue(new Callback<Mensaje>() {
                    @Override
                    public void onResponse(Call<Mensaje> call, Response<Mensaje> response) {
                        if (!response.isSuccessful()) {
                            Log.e("TAG", "ERROR > " + response.code());
                        } else {
                            String msg_aux="";
                            Integer car=3;
                            Mensaje msg_ = response.body();
                            for (Output output : msg_.output){
                                msg_aux=msg_aux+output.msg+", ";
                                if (output.msg.contains("car"))
                                    car=car-1;
                            }

                            msg_aux=msg_aux+" : >> TEM "+String.valueOf(car)+" VAGAS";
                            txv_txt.setText(msg_aux);
                        }
                    }

                    @Override
                    public void onFailure(Call<Mensaje> call, Throwable t) {
                        Log.e("TAG", "Error:" + t.getMessage());
                    }
                });
                Picasso.get().load("https://www.ime.usp.br/~reynaldo/phd/internet_coisas/foto_.jpg").networkPolicy(NetworkPolicy.NO_CACHE).memoryPolicy(MemoryPolicy.NO_CACHE).into(imv_fot);

            }
        });

    }

}
